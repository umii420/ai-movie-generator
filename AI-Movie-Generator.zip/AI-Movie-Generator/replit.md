# Cineforge — AI Movie Generator

Cineforge is a Flutter app for composing, organizing, and saving movie concepts. Gemini generates original movie concepts, scene descriptions, and short screenplays through the API server. The Gemini API key stays server-side; this does not render video clips, which still requires a video provider.

## Run & Operate

- `cd apps/ai-movie-generator && flutter pub get` — install Flutter dependencies
- `cd apps/ai-movie-generator && flutter run -d web-server --web-hostname 0.0.0.0 --web-port 8000` — run the Flutter Web preview
- `cd apps/ai-movie-generator && flutter analyze` — analyze the Flutter app
- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- Flutter 3.32 / Dart 3.8 app in `apps/ai-movie-generator`
- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `apps/ai-movie-generator/lib/` — Flutter app, local concept storage, screens, and theme
- `artifacts/api-server/` — shared Express API
- `artifacts/mockup-sandbox/` — design canvas preview server
- `lib/api-spec/openapi.yaml` — shared API contract
- `lib/db/src/schema/` — shared database schema

## Architecture decisions

- Movie concepts are stored on-device; the first version does not require accounts or a backend.
- The interface clearly reports that video generation is unavailable until a provider is configured.

## Product

- Compose a movie prompt, choose a style, duration, and aspect ratio, and save/reopen concepts from a local library.

## User preferences

- The user asked for a Flutter app.

## Gotchas

- Flutter Web can be previewed here. Android builds require an Android SDK, which is not installed in the current environment.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
