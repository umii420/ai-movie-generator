package com.cineforge.cineforge

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
