# Cineforge

Cineforge is a Flutter movie-idea studio. Write a prompt, choose a visual style,
length, and frame, then save the concept to the device library.

## Current scope

The app is in concept mode. It does not render video until a video-generation
provider is connected. Concepts are stored locally with `shared_preferences`.

## Run

```sh
cd apps/ai-movie-generator
flutter pub get
flutter run -d web-server --web-hostname 0.0.0.0 --web-port 8000
```

For an Android or iOS device, run `flutter run` with that device selected.
Building Android requires the Android SDK; building iOS requires macOS and
Xcode.
