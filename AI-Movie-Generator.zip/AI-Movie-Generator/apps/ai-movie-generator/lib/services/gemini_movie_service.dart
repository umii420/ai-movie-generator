import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../models/movie_package.dart';

class GeminiMovieService {
  GeminiMovieService({http.Client? client}) : _client = client ?? http.Client();

  static const _nativeApiBaseUrl =
      String.fromEnvironment('CINEFORGE_API_BASE_URL');
  static const _endpointPath = '/api/gemini/movie-package';

  final http.Client _client;

  Future<MoviePackage> generate({
    required String prompt,
    required String style,
    required String duration,
    required String aspectRatio,
  }) async {
    final uri = _endpointUri();
    late final http.Response response;
    try {
      response = await _client
          .post(
            uri,
            headers: const {'content-type': 'application/json'},
            body: jsonEncode({
              'prompt': prompt,
              'style': style,
              'duration': duration,
              'aspectRatio': aspectRatio,
            }),
          )
          .timeout(const Duration(seconds: 70));
    } on Exception {
      throw GeminiMovieException(
        'Could not reach the movie-writing service. Check your connection and try again.',
      );
    }

    final Object? decoded;
    try {
      decoded = jsonDecode(response.body);
    } on FormatException {
      throw GeminiMovieException(
        'The movie-writing service returned an unreadable response.',
      );
    }

    if (response.statusCode < 200 || response.statusCode >= 300) {
      final message = decoded is Map<String, dynamic>
          ? decoded['error']
          : null;
      throw GeminiMovieException(
        message is String
            ? message
            : 'Movie writing failed (${response.statusCode}). Please try again.',
      );
    }

    if (decoded is! Map<String, dynamic>) {
      throw GeminiMovieException(
        'The movie-writing service returned an unexpected response.',
      );
    }

    try {
      return MoviePackage.fromJson(decoded);
    } on Object {
      throw GeminiMovieException(
        'The generated story package was incomplete. Please try again.',
      );
    }
  }

  Uri _endpointUri() {
    if (kIsWeb) {
      return Uri.base.replace(
        path: _endpointPath,
        query: null,
        fragment: null,
      );
    }

    if (_nativeApiBaseUrl.isEmpty) {
      throw GeminiMovieException(
        'Set CINEFORGE_API_BASE_URL when building the mobile app to connect to its server.',
      );
    }

    final base = Uri.tryParse(_nativeApiBaseUrl);
    if (base == null || !base.hasScheme || base.host.isEmpty) {
      throw GeminiMovieException(
        'CINEFORGE_API_BASE_URL must be a complete server URL.',
      );
    }
    return base.replace(path: _endpointPath, query: null, fragment: null);
  }

  void close() => _client.close();
}

class GeminiMovieException implements Exception {
  const GeminiMovieException(this.message);

  final String message;

  @override
  String toString() => message;
}
