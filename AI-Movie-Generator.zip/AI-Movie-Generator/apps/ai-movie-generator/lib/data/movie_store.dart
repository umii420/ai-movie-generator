import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/movie_concept.dart';
import '../models/movie_package.dart';

class MovieStore extends ChangeNotifier {
  static const _storageKey = 'cineforge.movie-concepts.v1';
  List<MovieConcept> _concepts = [];

  List<MovieConcept> get concepts => List.unmodifiable(_concepts);

  Future<void> load() async {
    final preferences = await SharedPreferences.getInstance();
    final stored = preferences.getString(_storageKey);
    if (stored == null || stored.isEmpty) return;

    final decoded = jsonDecode(stored) as List<dynamic>;
    _concepts = decoded
        .map((item) =>
            MovieConcept.fromJson(item as Map<String, dynamic>))
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  Future<MovieConcept> create({
    required String prompt,
    required String style,
    required String duration,
    required String aspectRatio,
    MoviePackage? generatedPackage,
  }) async {
    final concept = MovieConcept.create(
      prompt: prompt,
      style: style,
      duration: duration,
      aspectRatio: aspectRatio,
      generatedPackage: generatedPackage,
    );
    final updated = [concept, ..._concepts];
    await _persist(updated);
    _concepts = updated;
    notifyListeners();
    return concept;
  }

  Future<void> delete(String id) async {
    final updated =
        _concepts.where((concept) => concept.id != id).toList();
    await _persist(updated);
    _concepts = updated;
    notifyListeners();
  }

  Future<void> _persist(List<MovieConcept> concepts) async {
    final preferences = await SharedPreferences.getInstance();
    final saved = await preferences.setString(
      _storageKey,
      jsonEncode(concepts.map((concept) => concept.toJson()).toList()),
    );
    if (!saved) {
      throw StateError('Local storage did not confirm the save.');
    }
  }
}
