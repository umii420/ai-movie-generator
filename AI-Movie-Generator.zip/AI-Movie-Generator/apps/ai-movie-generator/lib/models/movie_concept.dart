import 'movie_package.dart';

class MovieConcept {
  const MovieConcept({
    required this.id,
    required this.prompt,
    required this.style,
    required this.duration,
    required this.aspectRatio,
    required this.createdAt,
    this.generatedPackage,
  });

  final String id;
  final String prompt;
  final String style;
  final String duration;
  final String aspectRatio;
  final DateTime createdAt;
  final MoviePackage? generatedPackage;

  factory MovieConcept.create({
    required String prompt,
    required String style,
    required String duration,
    required String aspectRatio,
    MoviePackage? generatedPackage,
  }) {
    return MovieConcept(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      prompt: prompt,
      style: style,
      duration: duration,
      aspectRatio: aspectRatio,
      createdAt: DateTime.now(),
      generatedPackage: generatedPackage,
    );
  }

  factory MovieConcept.fromJson(Map<String, dynamic> json) {
    final generatedPackageJson = json['generatedPackage'];
    return MovieConcept(
      id: json['id'] as String,
      prompt: json['prompt'] as String,
      style: json['style'] as String,
      duration: json['duration'] as String,
      aspectRatio: json['aspectRatio'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      generatedPackage: generatedPackageJson == null
          ? null
          : MoviePackage.fromJson(
              generatedPackageJson as Map<String, dynamic>,
            ),
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'prompt': prompt,
        'style': style,
        'duration': duration,
        'aspectRatio': aspectRatio,
        'createdAt': createdAt.toIso8601String(),
        if (generatedPackage != null)
          'generatedPackage': generatedPackage!.toJson(),
      };
}
