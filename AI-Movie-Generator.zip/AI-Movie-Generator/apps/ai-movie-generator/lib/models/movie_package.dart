class MovieScene {
  const MovieScene({
    required this.number,
    required this.slugline,
    required this.durationSeconds,
    required this.description,
    required this.camera,
  });

  final int number;
  final String slugline;
  final int durationSeconds;
  final String description;
  final String camera;

  factory MovieScene.fromJson(Map<String, dynamic> json) => MovieScene(
        number: json['number'] as int,
        slugline: json['slugline'] as String,
        durationSeconds: json['durationSeconds'] as int,
        description: json['description'] as String,
        camera: json['camera'] as String,
      );

  Map<String, dynamic> toJson() => {
        'number': number,
        'slugline': slugline,
        'durationSeconds': durationSeconds,
        'description': description,
        'camera': camera,
      };
}

class MoviePackage {
  const MoviePackage({
    required this.title,
    required this.logline,
    required this.synopsis,
    required this.genre,
    required this.scenes,
    required this.screenplay,
  });

  final String title;
  final String logline;
  final String synopsis;
  final String genre;
  final List<MovieScene> scenes;
  final String screenplay;

  factory MoviePackage.fromJson(Map<String, dynamic> json) => MoviePackage(
        title: json['title'] as String,
        logline: json['logline'] as String,
        synopsis: json['synopsis'] as String,
        genre: json['genre'] as String,
        scenes: (json['scenes'] as List<dynamic>)
            .map((scene) =>
                MovieScene.fromJson(scene as Map<String, dynamic>))
            .toList(),
        screenplay: json['screenplay'] as String,
      );

  Map<String, dynamic> toJson() => {
        'title': title,
        'logline': logline,
        'synopsis': synopsis,
        'genre': genre,
        'scenes': scenes.map((scene) => scene.toJson()).toList(),
        'screenplay': screenplay,
      };
}
