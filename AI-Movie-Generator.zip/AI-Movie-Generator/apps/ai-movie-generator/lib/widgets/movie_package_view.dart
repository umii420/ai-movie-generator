import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/movie_package.dart';
import '../theme/app_theme.dart';

class MoviePackageView extends StatelessWidget {
  const MoviePackageView({
    super.key,
    required this.package,
    required this.onSave,
  });

  final MoviePackage package;
  final Future<void> Function() onSave;

  Future<void> _copyScreenplay(BuildContext context) async {
    await Clipboard.setData(ClipboardData(text: package.screenplay));
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Screenplay copied to clipboard.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppTheme.panel,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppTheme.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _Eyebrow(icon: Icons.auto_awesome, label: 'YOUR STORY PACKAGE'),
          const SizedBox(height: 18),
          Text(
            package.title,
            style: const TextStyle(
              color: AppTheme.white,
              fontSize: 27,
              height: 1.1,
              fontWeight: FontWeight.w800,
              letterSpacing: -.7,
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            children: [
              _Tag(package.genre),
              _Tag('${package.scenes.length} scenes'),
            ],
          ),
          const SizedBox(height: 19),
          _LabeledText(label: 'LOGLINE', text: package.logline),
          const SizedBox(height: 15),
          _LabeledText(label: 'CONCEPT', text: package.synopsis),
          const SizedBox(height: 23),
          const _Eyebrow(icon: Icons.view_timeline_outlined, label: 'SCENE BREAKDOWN'),
          const SizedBox(height: 12),
          for (final scene in package.scenes) ...[
            _SceneCard(scene: scene),
            const SizedBox(height: 9),
          ],
          const SizedBox(height: 17),
          Row(
            children: [
              const Expanded(
                child: _Eyebrow(
                  icon: Icons.notes_rounded,
                  label: 'SHORT SCREENPLAY',
                ),
              ),
              TextButton.icon(
                onPressed: () => _copyScreenplay(context),
                icon: const Icon(Icons.copy_rounded, size: 14),
                label: const Text('Copy'),
                style: TextButton.styleFrom(
                  foregroundColor: AppTheme.lime,
                  textStyle: const TextStyle(fontSize: 11),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.ink,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: AppTheme.line),
            ),
            child: SelectableText(
              package.screenplay,
              style: const TextStyle(
                color: AppTheme.soft,
                fontFamily: 'monospace',
                fontSize: 12,
                height: 1.65,
              ),
            ),
          ),
          const SizedBox(height: 18),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: FilledButton.icon(
              onPressed: onSave,
              icon: const Icon(Icons.bookmark_add_outlined, size: 17),
              label: const Text('Save story package to library'),
              style: FilledButton.styleFrom(
                backgroundColor: AppTheme.lime,
                foregroundColor: AppTheme.ink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(13),
                ),
                textStyle: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SceneCard extends StatelessWidget {
  const _SceneCard({required this.scene});

  final MovieScene scene;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.ink,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: AppTheme.lime.withValues(alpha: .1),
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Text(
                  'SCENE ${scene.number.toString().padLeft(2, '0')}',
                  style: const TextStyle(
                    color: AppTheme.lime,
                    fontSize: 8,
                    fontWeight: FontWeight.w800,
                    letterSpacing: .7,
                  ),
                ),
              ),
              const Spacer(),
              Text(
                '${scene.durationSeconds}s',
                style: const TextStyle(color: AppTheme.muted, fontSize: 10),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            scene.slugline,
            style: const TextStyle(
              color: AppTheme.white,
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            scene.description,
            style: const TextStyle(
              color: AppTheme.soft,
              fontSize: 11,
              height: 1.5,
            ),
          ),
          const SizedBox(height: 7),
          Text(
            'CAMERA  ${scene.camera}',
            style: const TextStyle(
              color: AppTheme.muted,
              fontSize: 9,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _LabeledText extends StatelessWidget {
  const _LabeledText({required this.label, required this.text});

  final String label;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: AppTheme.muted,
            fontSize: 9,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.1,
          ),
        ),
        const SizedBox(height: 6),
        Text(
          text,
          style: const TextStyle(
            color: AppTheme.soft,
            fontSize: 12,
            height: 1.55,
          ),
        ),
      ],
    );
  }
}

class _Eyebrow extends StatelessWidget {
  const _Eyebrow({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: AppTheme.lime, size: 15),
        const SizedBox(width: 7),
        Text(
          label,
          style: const TextStyle(
            color: AppTheme.soft,
            fontSize: 9,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.15,
          ),
        ),
      ],
    );
  }
}

class _Tag extends StatelessWidget {
  const _Tag(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
        decoration: BoxDecoration(
          color: AppTheme.panelRaised,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          text,
          style: const TextStyle(color: AppTheme.soft, fontSize: 9),
        ),
      );
}
