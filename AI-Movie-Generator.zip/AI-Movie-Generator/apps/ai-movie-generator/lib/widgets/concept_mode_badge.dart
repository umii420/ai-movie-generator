import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class ConceptModeBadge extends StatelessWidget {
  const ConceptModeBadge({super.key, this.compact = false});
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 9 : 11,
        vertical: compact ? 6 : 7,
      ),
      decoration: BoxDecoration(
        color: AppTheme.amber.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: AppTheme.amber.withValues(alpha: .2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.circle, size: 6, color: AppTheme.amber),
          const SizedBox(width: 7),
          Text(
            compact ? 'PREVIEW' : 'CONCEPT MODE',
            style: TextStyle(
              color: AppTheme.amber,
              fontSize: compact ? 8 : 9,
              letterSpacing: 1,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}
