import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class FilmArtwork extends StatelessWidget {
  const FilmArtwork({
    super.key,
    required this.title,
    required this.seed,
    this.aspectRatio = 1.45,
  });

  final String title;
  final int seed;
  final double aspectRatio;

  static const _palettes = [
    [Color(0xFF263D42), Color(0xFF111A21), Color(0xFF66765B)],
    [Color(0xFF493D2E), Color(0xFF221B1D), Color(0xFF9A7050)],
    [Color(0xFF3D3C5B), Color(0xFF1B1A2C), Color(0xFF82769B)],
    [Color(0xFF2C493B), Color(0xFF141F1B), Color(0xFF82936D)],
    [Color(0xFF573C35), Color(0xFF221719), Color(0xFFB27757)],
  ];

  @override
  Widget build(BuildContext context) {
    final colors = _palettes[seed.abs() % _palettes.length];
    return AspectRatio(
      aspectRatio: aspectRatio,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(13),
        child: Stack(
          fit: StackFit.expand,
          children: [
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: colors,
                ),
              ),
            ),
            CustomPaint(painter: _FramePainter(seed: seed, colors: colors)),
            DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withValues(alpha: .06),
                    Colors.black.withValues(alpha: .68),
                  ],
                  stops: const [0.18, 0.48, 1],
                ),
              ),
            ),
            Positioned(
              left: 12,
              right: 12,
              bottom: 11,
              child: Text(
                title.trim().isEmpty ? 'UNTITLED SCENE' : title.toUpperCase(),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: AppTheme.white,
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  height: 1.2,
                  letterSpacing: .8,
                ),
              ),
            ),
            Positioned(
              right: 10,
              top: 10,
              child: Container(
                width: 23,
                height: 23,
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: .3),
                  borderRadius: BorderRadius.circular(7),
                  border: Border.all(color: Colors.white.withValues(alpha: .16)),
                ),
                child: const Icon(Icons.play_arrow_rounded,
                    color: AppTheme.white, size: 15),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FramePainter extends CustomPainter {
  const _FramePainter({required this.seed, required this.colors});

  final int seed;
  final List<Color> colors;

  @override
  void paint(Canvas canvas, Size size) {
    final accent = colors.last.withValues(alpha: .72);
    final planet = Paint()
      ..shader = RadialGradient(
        colors: [
          accent.withValues(alpha: .88),
          colors.first.withValues(alpha: .3),
          colors.first.withValues(alpha: 0),
        ],
      ).createShader(Rect.fromCircle(
        center: Offset(size.width * .68, size.height * .39),
        radius: size.width * .57,
      ));
    canvas.drawCircle(
      Offset(size.width * .68, size.height * .39),
      size.width * .57,
      planet,
    );

    final orbitPaint = Paint()
      ..color = Colors.white.withValues(alpha: .13)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    for (var i = 0; i < 3; i++) {
      final rect = Rect.fromCenter(
        center: Offset(size.width * .63, size.height * .46),
        width: size.width * (.52 + i * .16),
        height: size.height * (.2 + i * .11),
      );
      canvas.drawOval(rect, orbitPaint);
    }

    final linePaint = Paint()
      ..color = AppTheme.lime.withValues(alpha: .65)
      ..strokeWidth = 1.1;
    final offset = (seed.abs() % 13) / 45;
    for (var i = 0; i < 5; i++) {
      final x = size.width * (.12 + i * .055 + offset);
      canvas.drawLine(
        Offset(x, size.height * .16),
        Offset(x + size.width * .04, size.height * .57),
        linePaint..color = AppTheme.lime.withValues(alpha: .24 - i * .025),
      );
    }
    final dotPaint = Paint()..color = Colors.white.withValues(alpha: .72);
    for (var i = 0; i < 7; i++) {
      final x = size.width * ((i * 31 + seed.abs()) % 100 / 100);
      final y = size.height * ((i * 19 + 13) % 52 / 100);
      canvas.drawCircle(Offset(x, y), i % 3 == 0 ? 1.5 : 1, dotPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _FramePainter oldDelegate) =>
      oldDelegate.seed != seed || oldDelegate.colors != colors;
}
