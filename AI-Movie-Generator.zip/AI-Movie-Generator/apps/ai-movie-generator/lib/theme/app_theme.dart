import 'package:flutter/material.dart';

abstract final class AppTheme {
  static const ink = Color(0xFF0C0D0B);
  static const rail = Color(0xFF10110F);
  static const panel = Color(0xFF171915);
  static const panelRaised = Color(0xFF1D201A);
  static const line = Color(0xFF292C25);
  static const lime = Color(0xFFD3F36B);
  static const amber = Color(0xFFE9B56C);
  static const white = Color(0xFFF3F2EC);
  static const soft = Color(0xFFC2C4BB);
  static const muted = Color(0xFF81847A);

  static final dark = ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: ink,
    colorScheme: const ColorScheme.dark(
      primary: lime,
      onPrimary: ink,
      secondary: amber,
      surface: panel,
      onSurface: white,
      outline: line,
      error: Color(0xFFE78679),
    ),
    snackBarTheme: SnackBarThemeData(
      backgroundColor: panelRaised,
      contentTextStyle: const TextStyle(color: white, fontSize: 13),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
    ),
    dialogTheme: DialogThemeData(
      backgroundColor: panel,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    ),
  );
}
