import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final horizontal = constraints.maxWidth < 560 ? 22.0 : 38.0;
        return SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(horizontal, 31, horizontal, 38),
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 790),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'WORKSPACE SETTINGS',
                    style: TextStyle(
                      color: AppTheme.muted,
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 1.6,
                    ),
                  ),
                  const SizedBox(height: 28),
                  Text(
                    'Your studio.',
                    style: TextStyle(
                      color: AppTheme.white,
                      fontSize: constraints.maxWidth < 560 ? 30 : 36,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -1.2,
                    ),
                  ),
                  const SizedBox(height: 9),
                  const Text(
                    'Control your local workspace and movie generation setup.',
                    style: TextStyle(color: AppTheme.muted, fontSize: 13),
                  ),
                  const SizedBox(height: 27),
                  _SettingsPanel(
                    title: 'VIDEO GENERATION',
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: AppTheme.amber.withValues(alpha: .1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: const Icon(Icons.movie_filter_outlined,
                                  color: AppTheme.amber, size: 19),
                            ),
                            const SizedBox(width: 13),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'No video provider connected',
                                    style: TextStyle(
                                      color: AppTheme.white,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 13,
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  Text(
                                    'Cineforge is in concept mode. You can save and revisit prompts, but it cannot render AI movies yet.',
                                    style: TextStyle(
                                      color: AppTheme.muted,
                                      fontSize: 11,
                                      height: 1.55,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(width: 10),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 9, vertical: 6),
                              decoration: BoxDecoration(
                                color: AppTheme.amber.withValues(alpha: .08),
                                borderRadius: BorderRadius.circular(20),
                              ),
                              child: const Text(
                                'NOT SET UP',
                                style: TextStyle(
                                  color: AppTheme.amber,
                                  fontSize: 8,
                                  letterSpacing: .7,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SettingsPanel(
                    title: 'LOCAL STORAGE',
                    child: const Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.phonelink_lock_outlined,
                            color: AppTheme.lime, size: 20),
                        SizedBox(width: 13),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Saved to this device',
                                style: TextStyle(
                                  color: AppTheme.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                ),
                              ),
                              SizedBox(height: 5),
                              Text(
                                'Your prompts and settings stay in local app storage. They are not sent to a server.',
                                style: TextStyle(
                                  color: AppTheme.muted,
                                  fontSize: 11,
                                  height: 1.55,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 14),
                  _SettingsPanel(
                    title: 'ABOUT CINEFORGE',
                    child: const Row(
                      children: [
                        Text(
                          'CINEFORGE',
                          style: TextStyle(
                            color: AppTheme.white,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 1,
                            fontSize: 12,
                          ),
                        ),
                        Spacer(),
                        Text(
                          'Flutter preview · v1.0.0',
                          style: TextStyle(color: AppTheme.muted, fontSize: 10),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _SettingsPanel extends StatelessWidget {
  const _SettingsPanel({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(19),
      decoration: BoxDecoration(
        color: AppTheme.panel,
        borderRadius: BorderRadius.circular(19),
        border: Border.all(color: AppTheme.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AppTheme.muted,
              fontSize: 9,
              letterSpacing: 1.3,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 17),
          child,
        ],
      ),
    );
  }
}
