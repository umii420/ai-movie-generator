import 'package:flutter/material.dart';

import '../models/movie_package.dart';
import '../theme/app_theme.dart';
import '../widgets/concept_mode_badge.dart';
import '../widgets/movie_package_view.dart';

class CreateScreen extends StatelessWidget {
  const CreateScreen({
    super.key,
    required this.promptController,
    required this.style,
    required this.duration,
    required this.aspectRatio,
    required this.generatedPackage,
    required this.generationError,
    required this.isGenerating,
    required this.onPromptChanged,
    required this.onStyleChanged,
    required this.onDurationChanged,
    required this.onAspectRatioChanged,
    required this.onGenerate,
    required this.onSave,
    required this.onSaveGeneratedPackage,
  });

  final TextEditingController promptController;
  final String style;
  final String duration;
  final String aspectRatio;
  final MoviePackage? generatedPackage;
  final String? generationError;
  final bool isGenerating;
  final ValueChanged<String> onPromptChanged;
  final ValueChanged<String> onStyleChanged;
  final ValueChanged<String> onDurationChanged;
  final ValueChanged<String> onAspectRatioChanged;
  final Future<void> Function() onGenerate;
  final Future<void> Function() onSave;
  final Future<void> Function() onSaveGeneratedPackage;

  static const _quickStarts = [
    (
      title: 'The last train',
      prompt:
          'At midnight, a train arrives at a station that disappeared from every map. One passenger is waiting.',
      icon: Icons.train_rounded,
      color: Color(0xFFB7C9D9),
    ),
    (
      title: 'A borrowed moon',
      prompt:
          'A young lighthouse keeper discovers a second moon reflected in the sea, and someone is calling from it.',
      icon: Icons.nights_stay_rounded,
      color: Color(0xFFE3C184),
    ),
    (
      title: 'Small worlds',
      prompt:
          'Inside a quiet greenhouse, tiny paper creatures begin rebuilding a miniature city after dark.',
      icon: Icons.local_florist_rounded,
      color: Color(0xFFB9D487),
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 1080;
        final horizontalPadding = constraints.maxWidth < 560 ? 22.0 : 38.0;
        return SingleChildScrollView(
          padding: EdgeInsets.fromLTRB(horizontalPadding, 30, horizontalPadding, 38),
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1260),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _PageTopline(),
                  const SizedBox(height: 30),
                  Text(
                    'Make a little\nmovie magic.',
                    style: TextStyle(
                      fontSize: constraints.maxWidth < 560 ? 34 : 43,
                      height: 1.05,
                      fontWeight: FontWeight.w800,
                      letterSpacing: -1.9,
                      color: AppTheme.white,
                    ),
                  ),
                  const SizedBox(height: 12),
                  ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: 530),
                    child: Text(
                      'Start with a scene, a feeling, or a strange little idea. Gemini can shape it into a concept, scene plan, and short screenplay.',
                      style: TextStyle(
                        color: AppTheme.muted,
                        height: 1.65,
                        fontSize: 14,
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                  if (wide)
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(flex: 7, child: _editor(context)),
                        const SizedBox(width: 24),
                        Expanded(flex: 4, child: _inspirationPanel(context)),
                      ],
                    )
                  else
                    Column(
                      children: [
                        _editor(context),
                        const SizedBox(height: 23),
                        _inspirationPanel(context),
                      ],
                    ),
                  if (generationError != null) ...[
                    const SizedBox(height: 20),
                    _GenerationError(message: generationError!),
                  ],
                  if (generatedPackage != null) ...[
                    const SizedBox(height: 20),
                    MoviePackageView(
                      package: generatedPackage!,
                      onSave: onSaveGeneratedPackage,
                    ),
                  ],
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _editor(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppTheme.panel,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: AppTheme.line),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const _SectionMark(number: '01'),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'THE STORY',
                  style: TextStyle(
                    color: AppTheme.soft,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              AnimatedBuilder(
                animation: promptController,
                builder: (context, _) => Text(
                  '${promptController.text.length}/500',
                  style:
                      const TextStyle(color: AppTheme.muted, fontSize: 10),
                ),
              ),
            ],
          ),
          const SizedBox(height: 17),
          TextField(
            controller: promptController,
            maxLength: 500,
            enabled: !isGenerating,
            onChanged: onPromptChanged,
            minLines: 5,
            maxLines: 7,
            style: const TextStyle(
              color: AppTheme.white,
              fontSize: 14,
              height: 1.6,
            ),
            decoration: InputDecoration(
              counterText: '',
              hintText:
                  'A lost astronomer finds a radio that picks up tomorrow’s weather…',
              hintStyle: const TextStyle(color: AppTheme.muted, height: 1.6),
              filled: true,
              fillColor: AppTheme.ink,
              contentPadding: const EdgeInsets.all(16),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: const BorderSide(color: AppTheme.line),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: const BorderSide(color: AppTheme.line),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide:
                    const BorderSide(color: AppTheme.lime, width: 1.2),
              ),
            ),
          ),
          const SizedBox(height: 24),
          const _SectionMark(number: '02', label: 'THE LOOK'),
          const SizedBox(height: 15),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final option in const [
                'Cinematic',
                'Anime',
                'Stop motion',
                'Documentary',
              ])
                _SelectChip(
                  label: option,
                  selected: style == option,
                  enabled: !isGenerating,
                  onTap: () => onStyleChanged(option),
                ),
            ],
          ),
          const SizedBox(height: 23),
          const _SectionMark(number: '03', label: 'THE FRAME'),
          const SizedBox(height: 15),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final option in const ['16:9', '9:16', '1:1'])
                _SelectChip(
                  label: option,
                  selected: aspectRatio == option,
                  enabled: !isGenerating,
                  icon: option == '9:16'
                      ? Icons.crop_portrait_rounded
                      : option == '1:1'
                          ? Icons.crop_square_rounded
                          : Icons.crop_16_9_rounded,
                  onTap: () => onAspectRatioChanged(option),
                ),
              const SizedBox(width: 5),
              for (final option in const ['5 sec', '10 sec', '15 sec'])
                _SelectChip(
                  label: option,
                  selected: duration == option,
                  enabled: !isGenerating,
                  onTap: () => onDurationChanged(option),
                ),
            ],
          ),
          const SizedBox(height: 24),
          Container(
            padding: const EdgeInsets.fromLTRB(12, 11, 13, 11),
            decoration: BoxDecoration(
              color: AppTheme.amber.withValues(alpha: .055),
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: AppTheme.amber.withValues(alpha: .16)),
            ),
            child: const Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.info_outline_rounded,
                    size: 16, color: AppTheme.amber),
                SizedBox(width: 9),
                Expanded(
                  child: Text(
                    'Gemini writes the concept, scene descriptions, and screenplay. It does not render video clips.',
                    style: TextStyle(
                      color: AppTheme.soft,
                      height: 1.45,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 15),
          SizedBox(
            width: double.infinity,
            height: 49,
            child: FilledButton.icon(
              onPressed: isGenerating ? null : onGenerate,
              style: FilledButton.styleFrom(
                backgroundColor: AppTheme.lime,
                foregroundColor: AppTheme.ink,
                disabledBackgroundColor: AppTheme.lime.withValues(alpha: .5),
                disabledForegroundColor: AppTheme.ink,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                textStyle: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                ),
              ),
              icon: isGenerating
                  ? const SizedBox(
                      width: 17,
                      height: 17,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: AppTheme.ink,
                      ),
                    )
                  : const Icon(Icons.auto_awesome, size: 18),
              label: Text(
                isGenerating ? 'Writing your story…' : 'Generate with Gemini',
              ),
            ),
          ),
          const SizedBox(height: 8),
          const Center(
            child: Text(
              'Uses your Gemini API quota.',
              style: TextStyle(color: AppTheme.muted, fontSize: 9),
            ),
          ),
          const SizedBox(height: 7),
          SizedBox(
            width: double.infinity,
            height: 42,
            child: OutlinedButton.icon(
              onPressed: isGenerating ? null : onSave,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.soft,
                side: const BorderSide(color: AppTheme.line),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(13),
                ),
                textStyle: const TextStyle(fontSize: 11),
              ),
              icon: const Icon(Icons.bookmark_add_outlined, size: 16),
              label: const Text('Save prompt without generating'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _inspirationPanel(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Row(
          children: [
            Icon(Icons.auto_awesome, color: AppTheme.lime, size: 16),
            SizedBox(width: 8),
            Text(
              'A SPARK TO START',
              style: TextStyle(
                color: AppTheme.soft,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.4,
              ),
            ),
          ],
        ),
        const SizedBox(height: 7),
        const Text(
          'Pick a prompt and make it your own.',
          style: TextStyle(color: AppTheme.muted, fontSize: 12, height: 1.5),
        ),
        const SizedBox(height: 15),
        for (final spark in _quickStarts) ...[
          _SparkCard(
            title: spark.title,
            prompt: spark.prompt,
            icon: spark.icon,
            color: spark.color,
            onTap: () {
              promptController.text = spark.prompt;
              onPromptChanged(spark.prompt);
            },
          ),
          const SizedBox(height: 10),
        ],
      ],
    );
  }
}

class _PageTopline extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Row(
      children: [
        Text(
          'YOUR PRIVATE MOVIE STUDIO',
          style: TextStyle(
            color: AppTheme.muted,
            fontSize: 10,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.6,
          ),
        ),
        Spacer(),
        ConceptModeBadge(),
      ],
    );
  }
}

class _SectionMark extends StatelessWidget {
  const _SectionMark({required this.number, this.label});
  final String number;
  final String? label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 23,
          height: 23,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: AppTheme.panelRaised,
            borderRadius: BorderRadius.circular(7),
            border: Border.all(color: AppTheme.line),
          ),
          child: Text(
            number,
            style: const TextStyle(
              fontSize: 9,
              color: AppTheme.lime,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        if (label != null) ...[
          const SizedBox(width: 9),
          Text(
            label!,
            style: const TextStyle(
              color: AppTheme.soft,
              fontSize: 10,
              fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
            ),
          ),
        ],
      ],
    );
  }
}

class _SelectChip extends StatelessWidget {
  const _SelectChip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.icon,
    this.enabled = true,
  });
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final IconData? icon;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? AppTheme.lime.withValues(alpha: .12) : AppTheme.ink,
      borderRadius: BorderRadius.circular(30),
      child: InkWell(
        onTap: enabled ? onTap : null,
        borderRadius: BorderRadius.circular(30),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            border: Border.all(
              color: selected ? AppTheme.lime.withValues(alpha: .52) : AppTheme.line,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (icon != null) ...[
                Icon(
                  icon,
                  size: 14,
                color: !enabled
                    ? AppTheme.muted.withValues(alpha: .5)
                    : selected
                        ? AppTheme.lime
                        : AppTheme.muted,
                ),
                const SizedBox(width: 6),
              ],
              Text(
                label,
                style: TextStyle(
                  color: !enabled
                      ? AppTheme.muted
                      : selected
                          ? AppTheme.white
                          : AppTheme.soft,
                  fontSize: 11,
                  fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SparkCard extends StatelessWidget {
  const _SparkCard({
    required this.title,
    required this.prompt,
    required this.icon,
    required this.color,
    required this.onTap,
  });

  final String title;
  final String prompt;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.panel,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppTheme.line),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 34,
                height: 34,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: .11),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, size: 17, color: color),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontWeight: FontWeight.w700, fontSize: 12)),
                    const SizedBox(height: 5),
                    Text(
                      prompt,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: AppTheme.muted,
                        fontSize: 11,
                        height: 1.45,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 7),
              const Icon(Icons.add, size: 17, color: AppTheme.muted),
            ],
          ),
        ),
      ),
    );
  }
}

class _GenerationError extends StatelessWidget {
  const _GenerationError({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFF402B29),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF8F514A)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.error_outline_rounded,
              color: Color(0xFFE78679), size: 17),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              message,
              style: const TextStyle(
                color: AppTheme.soft,
                fontSize: 12,
                height: 1.45,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
