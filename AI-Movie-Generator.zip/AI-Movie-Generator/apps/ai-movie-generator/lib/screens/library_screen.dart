import 'package:flutter/material.dart';

import '../data/movie_store.dart';
import '../models/movie_concept.dart';
import '../theme/app_theme.dart';
import '../widgets/film_artwork.dart';

class LibraryScreen extends StatefulWidget {
  const LibraryScreen({
    super.key,
    required this.store,
    required this.onEdit,
    required this.onCreate,
  });

  final MovieStore store;
  final ValueChanged<MovieConcept> onEdit;
  final VoidCallback onCreate;

  @override
  State<LibraryScreen> createState() => _LibraryScreenState();
}

class _LibraryScreenState extends State<LibraryScreen> {
  bool _showDeleteDialog = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: widget.store,
      builder: (context, _) {
        return LayoutBuilder(
          builder: (context, constraints) {
            final horizontal = constraints.maxWidth < 560 ? 22.0 : 38.0;
            return SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(horizontal, 31, horizontal, 38),
              child: Align(
                alignment: Alignment.topCenter,
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1100),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _LibraryTopline(conceptCount: widget.store.concepts.length),
                      const SizedBox(height: 28),
                      Text(
                        'Your story shelf.',
                        style: TextStyle(
                          color: AppTheme.white,
                          fontSize: constraints.maxWidth < 560 ? 30 : 36,
                          fontWeight: FontWeight.w800,
                          letterSpacing: -1.2,
                        ),
                      ),
                      const SizedBox(height: 9),
                      const Text(
                        'Saved ideas, waiting for their first frame.',
                        style: TextStyle(
                          color: AppTheme.muted,
                          fontSize: 13,
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 26),
                      if (widget.store.concepts.isEmpty)
                        _EmptyLibrary(onCreate: widget.onCreate)
                      else
                        _ConceptGrid(
                          concepts: widget.store.concepts,
                          onEdit: widget.onEdit,
                          onDelete: _confirmDelete,
                        ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _confirmDelete(MovieConcept concept) async {
    if (_showDeleteDialog) return;
    _showDeleteDialog = true;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Delete this concept?'),
        content: const Text(
          'This removes the saved idea from this device. It cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Keep it'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFE78679),
              foregroundColor: AppTheme.ink,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    _showDeleteDialog = false;
    if (confirmed == true) {
      await widget.store.delete(concept.id);
    }
  }
}

class _LibraryTopline extends StatelessWidget {
  const _LibraryTopline({required this.conceptCount});
  final int conceptCount;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Text(
          'MY MOVIE LIBRARY',
          style: TextStyle(
            color: AppTheme.muted,
            fontSize: 10,
            fontWeight: FontWeight.w800,
            letterSpacing: 1.6,
          ),
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
          decoration: BoxDecoration(
            color: AppTheme.panel,
            borderRadius: BorderRadius.circular(30),
            border: Border.all(color: AppTheme.line),
          ),
          child: Text(
            '$conceptCount ${conceptCount == 1 ? 'CONCEPT' : 'CONCEPTS'}',
            style: const TextStyle(
              color: AppTheme.soft,
              fontSize: 9,
              letterSpacing: .9,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}

class _EmptyLibrary extends StatelessWidget {
  const _EmptyLibrary({required this.onCreate});
  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 42),
      decoration: BoxDecoration(
        color: AppTheme.panel,
        borderRadius: BorderRadius.circular(23),
        border: Border.all(color: AppTheme.line),
      ),
      child: Column(
        children: [
          Container(
            width: 66,
            height: 66,
            decoration: BoxDecoration(
              color: AppTheme.lime.withValues(alpha: .1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Icon(Icons.local_movies_outlined,
                color: AppTheme.lime, size: 30),
          ),
          const SizedBox(height: 18),
          const Text(
            'Nothing on the shelf yet.',
            style: TextStyle(
              fontSize: 17,
              color: AppTheme.white,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          ConstrainedBox(
            constraints: BoxConstraints(maxWidth: 330),
            child: Text(
              'Save an idea from the studio and it’ll be here whenever you’re ready to shape it.',
              textAlign: TextAlign.center,
              style: TextStyle(color: AppTheme.muted, height: 1.55, fontSize: 12),
            ),
          ),
          const SizedBox(height: 21),
          OutlinedButton.icon(
            onPressed: onCreate,
            icon: const Icon(Icons.add_rounded, size: 17),
            label: const Text('Start a concept'),
          ),
        ],
      ),
    );
  }
}

class _ConceptGrid extends StatelessWidget {
  const _ConceptGrid({
    required this.concepts,
    required this.onEdit,
    required this.onDelete,
  });

  final List<MovieConcept> concepts;
  final ValueChanged<MovieConcept> onEdit;
  final ValueChanged<MovieConcept> onDelete;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 930 ? 2 : 1;
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: concepts.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            crossAxisSpacing: 13,
            mainAxisSpacing: 13,
            childAspectRatio: columns == 2 ? 2.08 : 1.9,
          ),
          itemBuilder: (context, index) {
            final concept = concepts[index];
            return _ConceptCard(
              concept: concept,
              onEdit: () => onEdit(concept),
              onDelete: () => onDelete(concept),
            );
          },
        );
      },
    );
  }
}

class _ConceptCard extends StatelessWidget {
  const _ConceptCard({
    required this.concept,
    required this.onEdit,
    required this.onDelete,
  });

  final MovieConcept concept;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  String get _title {
    final generatedTitle = concept.generatedPackage?.title;
    if (generatedTitle != null && generatedTitle.trim().isNotEmpty) {
      return generatedTitle;
    }
    final words = concept.prompt
        .replaceAll(RegExp(r'[^A-Za-z0-9 ]'), ' ')
        .split(RegExp(r'\s+'))
        .where((word) => word.isNotEmpty)
        .take(4)
        .toList();
    if (words.isEmpty) return 'Untitled scene';
    final sentence = words.join(' ');
    return sentence.length > 28 ? '${sentence.substring(0, 25)}…' : sentence;
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppTheme.panel,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onEdit,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppTheme.line),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 112,
                child: FilmArtwork(
                  title: _title,
                  seed: concept.id.hashCode,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                           Icon(
                             Icons.circle,
                             color: concept.generatedPackage == null
                                 ? AppTheme.amber
                                 : AppTheme.lime,
                             size: 6,
                           ),
                          const SizedBox(width: 6),
                           Text(
                             concept.generatedPackage == null
                                 ? 'SAVED CONCEPT'
                                 : 'STORY PACKAGE',
                             style: TextStyle(
                               color: concept.generatedPackage == null
                                   ? AppTheme.amber
                                   : AppTheme.lime,
                               fontSize: 8,
                               fontWeight: FontWeight.w800,
                               letterSpacing: .8,
                            ),
                          ),
                          const Spacer(),
                          PopupMenuButton<String>(
                            iconSize: 18,
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                            tooltip: 'Concept actions',
                            onSelected: (value) {
                              if (value == 'edit') onEdit();
                              if (value == 'delete') onDelete();
                            },
                            itemBuilder: (context) => const [
                              PopupMenuItem(
                                value: 'edit',
                                child: Text('Edit prompt'),
                              ),
                              PopupMenuItem(
                                value: 'delete',
                                child: Text('Delete concept'),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 14,
                          color: AppTheme.white,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Expanded(
                        child: Text(
                          concept.generatedPackage?.logline ?? concept.prompt,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: AppTheme.muted,
                            fontSize: 10,
                            height: 1.45,
                          ),
                        ),
                      ),
                      Wrap(
                        spacing: 6,
                        runSpacing: 5,
                        children: [
                          _MetaTag(concept.style),
                          _MetaTag('${concept.duration} · ${concept.aspectRatio}'),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _MetaTag extends StatelessWidget {
  const _MetaTag(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
      decoration: BoxDecoration(
        color: AppTheme.panelRaised,
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label,
        style: const TextStyle(color: AppTheme.soft, fontSize: 8),
      ),
    );
  }
}
