import 'package:flutter/material.dart';

import 'data/movie_store.dart';
import 'models/movie_concept.dart';
import 'models/movie_package.dart';
import 'services/gemini_movie_service.dart';
import 'screens/create_screen.dart';
import 'screens/library_screen.dart';
import 'screens/settings_screen.dart';
import 'theme/app_theme.dart';
import 'widgets/concept_mode_badge.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = MovieStore();
  await store.load();
  runApp(CineforgeApp(store: store));
}

class CineforgeApp extends StatelessWidget {
  const CineforgeApp({super.key, required this.store});

  final MovieStore store;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cineforge — AI Movie Studio',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      home: StudioShell(store: store),
    );
  }
}

class StudioShell extends StatefulWidget {
  const StudioShell({super.key, required this.store});

  final MovieStore store;

  @override
  State<StudioShell> createState() => _StudioShellState();
}

class _StudioShellState extends State<StudioShell> {
  final _promptController = TextEditingController();
  final _geminiMovieService = GeminiMovieService();
  int _selectedIndex = 0;
  String _style = 'Cinematic';
  String _duration = '10 sec';
  String _ratio = '16:9';
  bool _isGenerating = false;
  MoviePackage? _generatedPackage;
  String? _generationError;
  int _generationRequestId = 0;

  @override
  void dispose() {
    _promptController.dispose();
    _geminiMovieService.close();
    super.dispose();
  }

  void _clearGeneratedPackage() {
    if (_generatedPackage == null &&
        _generationError == null &&
        !_isGenerating) {
      return;
    }
    _generationRequestId++;
    setState(() {
      _isGenerating = false;
      _generatedPackage = null;
      _generationError = null;
    });
  }

  void _updateStyle(String value) {
    _generationRequestId++;
    setState(() {
      _style = value;
      _isGenerating = false;
      _generatedPackage = null;
      _generationError = null;
    });
  }

  void _updateDuration(String value) {
    _generationRequestId++;
    setState(() {
      _duration = value;
      _isGenerating = false;
      _generatedPackage = null;
      _generationError = null;
    });
  }

  void _updateAspectRatio(String value) {
    _generationRequestId++;
    setState(() {
      _ratio = value;
      _isGenerating = false;
      _generatedPackage = null;
      _generationError = null;
    });
  }

  Future<void> _generateMoviePackage() async {
    final prompt = _promptController.text.trim();
    if (prompt.length < 8) {
      setState(() {
        _generatedPackage = null;
        _generationError = 'Add at least 8 characters describing your idea.';
      });
      return;
    }

    final requestId = ++_generationRequestId;
    setState(() {
      _isGenerating = true;
      _generatedPackage = null;
      _generationError = null;
    });

    try {
      final result = await _geminiMovieService.generate(
        prompt: prompt,
        style: _style,
        duration: _duration,
        aspectRatio: _ratio,
      );
      if (!mounted || requestId != _generationRequestId) return;
      setState(() => _generatedPackage = result);
    } on GeminiMovieException catch (error) {
      if (!mounted || requestId != _generationRequestId) return;
      setState(() => _generationError = error.message);
    } catch (_) {
      if (!mounted || requestId != _generationRequestId) return;
      setState(() {
        _generationError = 'Something went wrong while writing your movie. Try again.';
      });
    } finally {
      if (mounted && requestId == _generationRequestId) {
        setState(() => _isGenerating = false);
      }
    }
  }

  Future<void> _saveConcept() async {
    final prompt = _promptController.text.trim();
    if (prompt.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Add a few words about your movie first.')),
      );
      return;
    }

    try {
      await widget.store.create(
        prompt: prompt,
        style: _style,
        duration: _duration,
        aspectRatio: _ratio,
      );
      if (!mounted) return;
      setState(() => _selectedIndex = 1);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Concept saved on this device.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save this concept: $error')),
      );
    }
  }

  Future<void> _saveGeneratedPackage() async {
    final generatedPackage = _generatedPackage;
    if (generatedPackage == null) return;

    try {
      await widget.store.create(
        prompt: _promptController.text.trim(),
        style: _style,
        duration: _duration,
        aspectRatio: _ratio,
        generatedPackage: generatedPackage,
      );
      if (!mounted) return;
      setState(() => _selectedIndex = 1);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Story package saved to your library.')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save this story package: $error')),
      );
    }
  }

  void _editConcept(MovieConcept concept) {
    _generationRequestId++;
    setState(() {
      _promptController.text = concept.prompt;
      _style = concept.style;
      _duration = concept.duration;
      _ratio = concept.aspectRatio;
      _isGenerating = false;
      _generatedPackage = concept.generatedPackage;
      _generationError = null;
      _selectedIndex = 0;
    });
  }

  void _startNewConcept() {
    _generationRequestId++;
    setState(() {
      _promptController.clear();
      _style = 'Cinematic';
      _duration = '10 sec';
      _ratio = '16:9';
      _isGenerating = false;
      _generatedPackage = null;
      _generationError = null;
      _selectedIndex = 0;
    });
  }

  Widget _currentScreen() {
    return IndexedStack(
      index: _selectedIndex,
      children: [
        CreateScreen(
          promptController: _promptController,
          style: _style,
          duration: _duration,
          aspectRatio: _ratio,
          generatedPackage: _generatedPackage,
          generationError: _generationError,
          isGenerating: _isGenerating,
          onPromptChanged: (_) => _clearGeneratedPackage(),
          onStyleChanged: _updateStyle,
          onDurationChanged: _updateDuration,
          onAspectRatioChanged: _updateAspectRatio,
          onGenerate: _generateMoviePackage,
          onSave: _saveConcept,
          onSaveGeneratedPackage: _saveGeneratedPackage,
        ),
        LibraryScreen(
          store: widget.store,
          onEdit: _editConcept,
          onCreate: _startNewConcept,
        ),
        const SettingsScreen(),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isDesktop = constraints.maxWidth >= 900;
        if (isDesktop) {
          return Scaffold(
            body: Row(
              children: [
                _DesktopRail(
                  selectedIndex: _selectedIndex,
                  onSelect: (index) => setState(() => _selectedIndex = index),
                  conceptCount: widget.store.concepts.length,
                ),
                Expanded(
                  child: SafeArea(
                    left: false,
                    child: _currentScreen(),
                  ),
                ),
              ],
            ),
          );
        }

        return Scaffold(
          body: SafeArea(
            bottom: false,
            child: Column(
              children: [
                _MobileHeader(),
                Expanded(child: _currentScreen()),
                _MobileNavigation(
                  selectedIndex: _selectedIndex,
                  onSelect: (index) => setState(() => _selectedIndex = index),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _DesktopRail extends StatelessWidget {
  const _DesktopRail({
    required this.selectedIndex,
    required this.onSelect,
    required this.conceptCount,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelect;
  final int conceptCount;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 236,
      decoration: const BoxDecoration(
        color: AppTheme.rail,
        border: Border(right: BorderSide(color: AppTheme.line)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 26, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _BrandLockup(),
          const SizedBox(height: 52),
          const _RailLabel('STUDIO'),
          const SizedBox(height: 12),
          _RailItem(
            icon: Icons.auto_awesome_outlined,
            selectedIcon: Icons.auto_awesome,
            label: 'Create movie',
            selected: selectedIndex == 0,
            onTap: () => onSelect(0),
          ),
          _RailItem(
            icon: Icons.movie_creation_outlined,
            selectedIcon: Icons.movie_creation,
            label: 'My concepts',
            trailing: conceptCount == 0 ? null : '$conceptCount',
            selected: selectedIndex == 1,
            onTap: () => onSelect(1),
          ),
          const SizedBox(height: 30),
          const _RailLabel('WORKSPACE'),
          const SizedBox(height: 12),
          _RailItem(
            icon: Icons.tune_rounded,
            selectedIcon: Icons.tune_rounded,
            label: 'Settings',
            selected: selectedIndex == 2,
            onTap: () => onSelect(2),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.panel,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppTheme.line),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.movie_filter_outlined,
                    size: 18, color: AppTheme.lime),
                SizedBox(height: 12),
                Text('Your next scene starts here.',
                    style: TextStyle(fontSize: 13, height: 1.4)),
                SizedBox(height: 6),
                Text(
                  'Concept mode is on. Your ideas are saved on this device.',
                  style: TextStyle(
                    color: AppTheme.muted,
                    fontSize: 11,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          const Row(
            children: [
              CircleAvatar(
                radius: 17,
                backgroundColor: AppTheme.lime,
                foregroundColor: AppTheme.ink,
                child: Text('C',
                    style:
                        TextStyle(fontWeight: FontWeight.w800, fontSize: 13)),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'My workspace',
                  style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
              ),
              Icon(Icons.more_horiz, size: 19, color: AppTheme.muted),
            ],
          ),
        ],
      ),
    );
  }
}

class _RailLabel extends StatelessWidget {
  const _RailLabel(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Text(
          text,
          style: const TextStyle(
            color: AppTheme.muted,
            fontSize: 10,
            fontWeight: FontWeight.w700,
            letterSpacing: 1.45,
          ),
        ),
      );
}

class _RailItem extends StatelessWidget {
  const _RailItem({
    required this.icon,
    required this.selectedIcon,
    required this.label,
    required this.selected,
    required this.onTap,
    this.trailing,
  });

  final IconData icon;
  final IconData selectedIcon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  final String? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Material(
        color: selected ? AppTheme.lime.withValues(alpha: .11) : Colors.transparent,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: SizedBox(
            height: 44,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                children: [
                  Icon(
                    selected ? selectedIcon : icon,
                    size: 18,
                    color: selected ? AppTheme.lime : AppTheme.muted,
                  ),
                  const SizedBox(width: 11),
                  Expanded(
                    child: Text(
                      label,
                      style: TextStyle(
                        color: selected ? AppTheme.white : AppTheme.soft,
                        fontSize: 13,
                        fontWeight:
                            selected ? FontWeight.w600 : FontWeight.w500,
                      ),
                    ),
                  ),
                  if (trailing != null)
                    Text(
                      trailing!,
                      style: const TextStyle(
                        color: AppTheme.muted,
                        fontSize: 11,
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _BrandLockup extends StatelessWidget {
  const _BrandLockup();

  @override
  Widget build(BuildContext context) {
    return const Row(
      children: [
        _BrandMark(size: 32),
        SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'CINEFORGE',
              style: TextStyle(
                fontSize: 15,
                fontWeight: FontWeight.w900,
                letterSpacing: 1.05,
              ),
            ),
            SizedBox(height: 2),
            Text(
              'AI MOVIE STUDIO',
              style: TextStyle(
                color: AppTheme.muted,
                fontSize: 8,
                letterSpacing: 1.55,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _BrandMark extends StatelessWidget {
  const _BrandMark({this.size = 29});
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AppTheme.lime,
        borderRadius: BorderRadius.circular(size * .32),
      ),
      child: Icon(
        Icons.play_arrow_rounded,
        color: AppTheme.ink,
        size: size * .76,
      ),
    );
  }
}

class _MobileHeader extends StatelessWidget {
  const _MobileHeader();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.fromLTRB(22, 14, 22, 12),
      child: Row(
        children: [
          _BrandMark(size: 30),
          SizedBox(width: 9),
          Text(
            'CINEFORGE',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w900,
              letterSpacing: 1.1,
            ),
          ),
          Spacer(),
          ConceptModeBadge(compact: true),
        ],
      ),
    );
  }
}

class _MobileNavigation extends StatelessWidget {
  const _MobileNavigation({
    required this.selectedIndex,
    required this.onSelect,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    const items = [
      (Icons.auto_awesome_outlined, Icons.auto_awesome, 'Create'),
      (Icons.movie_creation_outlined, Icons.movie_creation, 'Library'),
      (Icons.tune_rounded, Icons.tune_rounded, 'Settings'),
    ];
    return Container(
      decoration: const BoxDecoration(
        color: AppTheme.rail,
        border: Border(top: BorderSide(color: AppTheme.line)),
      ),
      padding: const EdgeInsets.fromLTRB(18, 7, 18, 7),
      child: Row(
        children: [
          for (var i = 0; i < items.length; i++)
            Expanded(
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => onSelect(i),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        selectedIndex == i ? items[i].$2 : items[i].$1,
                        size: 20,
                        color: selectedIndex == i
                            ? AppTheme.lime
                            : AppTheme.muted,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        items[i].$3,
                        style: TextStyle(
                          color: selectedIndex == i
                              ? AppTheme.white
                              : AppTheme.muted,
                          fontSize: 10,
                          fontWeight: selectedIndex == i
                              ? FontWeight.w700
                              : FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

