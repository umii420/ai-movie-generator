---
name: Workflow port collisions
description: Stale child processes can keep a workflow port occupied after a package-triggered restart fails.
---

If a workflow reports `EADDRINUSE` but its expected port still responds, the prior process may still be serving even though the workflow is marked failed. Stop that workflow through the workflow manager before restarting it.

**Why:** A package-triggered restart left the Flutter preview and API processes on ports 8000 and 8080; stopping each managed workflow cleared the conflicts and allowed one clean restart.

**How to apply:** Check the workflow logs and expected port first. For a custom Flutter workflow use `stopWorkflow`; for an artifact service use its managed workflow. Then restart once and confirm the listening log.
