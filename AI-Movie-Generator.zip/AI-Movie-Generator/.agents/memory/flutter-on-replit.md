---
name: Flutter on Replit
description: Flutter SDK discovery and preview constraints for this Replit workspace.
---

The Flutter SDK can be available as a Nix system dependency even when the language-module catalog reports no Flutter modules. Check the current environment before assuming Flutter cannot run.

**Why:** A Flutter module lookup returned none, but installing the Nix `flutter` system dependency provided a usable SDK and web-server target.

**How to apply:** If a future task asks for Flutter, check module availability, then check the `flutter` Nix dependency. Verify the desired targets separately: Flutter Web can run with `-d web-server`, while Android builds also need an Android SDK.
