import { Router, type IRouter } from "express";

const router: IRouter = Router();

const model = "gemini-3.6-flash";
const endpoint =
  `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
const requestsPerHour = 20;
const requestWindowMs = 60 * 60 * 1000;
const generationTimestamps: number[] = [];

const moviePackageSchema = {
  type: "OBJECT",
  properties: {
    title: { type: "STRING" },
    logline: { type: "STRING" },
    synopsis: { type: "STRING" },
    genre: { type: "STRING" },
    scenes: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          number: { type: "INTEGER" },
          slugline: { type: "STRING" },
          durationSeconds: { type: "INTEGER" },
          description: { type: "STRING" },
          camera: { type: "STRING" },
        },
        required: [
          "number",
          "slugline",
          "durationSeconds",
          "description",
          "camera",
        ],
      },
    },
    screenplay: { type: "STRING" },
  },
  required: ["title", "logline", "synopsis", "genre", "scenes", "screenplay"],
};

type MovieScene = {
  number: number;
  slugline: string;
  durationSeconds: number;
  description: string;
  camera: string;
};

type MoviePackage = {
  title: string;
  logline: string;
  synopsis: string;
  genre: string;
  scenes: MovieScene[];
  screenplay: string;
};

type MoviePackageRequest = {
  prompt: string;
  style: "Cinematic" | "Anime" | "Stop motion" | "Documentary";
  duration: "5 sec" | "10 sec" | "15 sec";
  aspectRatio: "16:9" | "9:16" | "1:1";
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function parseRequest(value: unknown): MoviePackageRequest | null {
  if (!isRecord(value)) return null;
  const { prompt, style, duration, aspectRatio } = value;

  if (
    typeof prompt !== "string" ||
    prompt.trim().length < 8 ||
    prompt.trim().length > 500 ||
    !["Cinematic", "Anime", "Stop motion", "Documentary"].includes(
      String(style),
    ) ||
    !["5 sec", "10 sec", "15 sec"].includes(String(duration)) ||
    !["16:9", "9:16", "1:1"].includes(String(aspectRatio))
  ) {
    return null;
  }

  return {
    prompt: prompt.trim(),
    style: style as MoviePackageRequest["style"],
    duration: duration as MoviePackageRequest["duration"],
    aspectRatio: aspectRatio as MoviePackageRequest["aspectRatio"],
  };
}

function isMovieScene(value: unknown): value is MovieScene {
  return (
    isRecord(value) &&
    Number.isInteger(value.number) &&
    typeof value.slugline === "string" &&
    Number.isInteger(value.durationSeconds) &&
    Number(value.durationSeconds) > 0 &&
    typeof value.description === "string" &&
    typeof value.camera === "string"
  );
}

function isMoviePackage(value: unknown): value is MoviePackage {
  return (
    isRecord(value) &&
    typeof value.title === "string" &&
    typeof value.logline === "string" &&
    typeof value.synopsis === "string" &&
    typeof value.genre === "string" &&
    Array.isArray(value.scenes) &&
    value.scenes.length >= 3 &&
    value.scenes.length <= 5 &&
    value.scenes.every(isMovieScene) &&
    typeof value.screenplay === "string"
  );
}

function consumeGenerationBudget(now: number): boolean {
  while (
    generationTimestamps.length > 0 &&
    now - generationTimestamps[0] >= requestWindowMs
  ) {
    generationTimestamps.shift();
  }

  if (generationTimestamps.length >= requestsPerHour) return false;
  generationTimestamps.push(now);
  return true;
}

router.post("/gemini/movie-package", async (req, res) => {
  const input = parseRequest(req.body);
  if (!input) {
    res.status(400).json({
      error:
        "Enter an idea of 8–500 characters and choose a supported style, length, and frame.",
    });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(503).json({
      error: "Gemini is not configured on the server yet.",
    });
    return;
  }

  if (!consumeGenerationBudget(Date.now())) {
    res.status(429).json({
      error: "This studio has reached its hourly generation limit. Try again later.",
    });
    return;
  }

  const sceneCount =
    input.duration === "5 sec" ? 3 : input.duration === "10 sec" ? 4 : 5;
  const prompt = [
    "Create an original short-film writing package from the user's idea.",
    `The target runtime is ${input.duration} and the frame is ${input.aspectRatio}.`,
    `Use this visual direction: ${input.style}.`,
    `Return exactly ${sceneCount} scenes in chronological order.`,
    "Give each scene a concrete slugline, a vivid visual/action description,",
    "a camera direction useful for a video-generation model, and a positive",
    "duration in seconds. Make the screenplay concise enough to fit the target runtime.",
    "Keep the concept, scene descriptions, and screenplay consistent with each other.",
    "Create original characters and settings; do not imitate a living filmmaker.",
    "",
    "User idea:",
    input.prompt,
  ].join(" ");

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-goog-api-key": apiKey,
      },
      body: JSON.stringify({
        systemInstruction: {
          parts: [
            {
              text: "You are a concise screenwriter and film previsualization assistant. Follow the requested JSON schema exactly. Do not include markdown or explanatory text outside the JSON.",
            },
          ],
        },
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          responseMimeType: "application/json",
          responseJsonSchema: moviePackageSchema,
          maxOutputTokens: 4096,
          temperature: 0.85,
        },
      }),
      signal: AbortSignal.timeout(60_000),
    });

    if (!response.ok) {
      if (response.status === 429) {
        res.status(429).json({
          error: "Gemini is busy or has reached its usage limit. Try again shortly.",
        });
        return;
      }

      req.log.warn(
        { providerStatus: response.status },
        "Gemini movie package generation failed",
      );
      res.status(502).json({
        error:
          response.status === 401 || response.status === 403
            ? "Gemini rejected the server credential. Check the saved API key."
            : "Gemini could not complete this request. Please try again.",
      });
      return;
    }

    const providerData: unknown = await response.json();
    if (!isRecord(providerData) || !Array.isArray(providerData.candidates)) {
      res.status(502).json({
        error: "Gemini returned an unexpected response. Please try again.",
      });
      return;
    }

    const candidate = providerData.candidates[0];
    const content =
      isRecord(candidate) && isRecord(candidate.content)
        ? candidate.content
        : null;
    const parts =
      content && Array.isArray(content.parts) ? content.parts : [];
    const generatedText = parts
      .filter(isRecord)
      .map((part) => part.text)
      .filter((text): text is string => typeof text === "string")
      .join("");

    if (!generatedText) {
      res.status(502).json({
        error: "Gemini returned no story content. Try a different idea.",
      });
      return;
    }

    let generated: unknown;
    try {
      generated = JSON.parse(generatedText);
    } catch {
      res.status(502).json({
        error: "Gemini returned an unreadable story package. Please try again.",
      });
      return;
    }

    if (!isMoviePackage(generated)) {
      res.status(502).json({
        error: "Gemini returned an incomplete story package. Please try again.",
      });
      return;
    }

    res.json(generated);
  } catch (error) {
    const isTimeout =
      error instanceof Error &&
      (error.name === "TimeoutError" || error.name === "AbortError");
    if (isTimeout) {
      res.status(504).json({
        error: "Gemini took too long to respond. Please try again.",
      });
      return;
    }

    req.log.error(
      { errorName: error instanceof Error ? error.name : "UnknownError" },
      "Gemini movie package request failed",
    );
    res.status(502).json({
      error: "Could not reach Gemini. Check the server connection and try again.",
    });
  }
});

export default router;
